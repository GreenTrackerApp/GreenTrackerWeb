# Web-App Bereinigung & Layout-Fix

Dieser Plan entfernt die (auf iOS nicht funktionierende) Intervall-Erinnerung und korrigiert das Layout der Log-Einträge für das iPhone.

## Geplante Änderungen

### 1. ViewModel (Logik)

#### [MODIFY] [SmokeViewModel.kt](file:///home/marcel/Schreibtisch/GreenTrackerWeb/composeApp/src/commonMain/kotlin/com/example/ui/viewmodel/SmokeViewModel.kt)
- **Entfernen der Hintergrund-Erinnerung**:
    - Löschen der `reminderInterval` Variable und der zugehörigen Funktionen (`setReminderInterval`, `loadSavedReminder`).
    - Entfernen der `startReminderTimer` Funktion, da diese in Web-Browsern (besonders Safari) im Hintergrund ohnehin gestoppt wird.
    - Die App bleibt dadurch "leichter" und verspricht keine Funktionen, die technisch nicht haltbar sind.

### 2. UI Screens (Design)

#### [MODIFY] [SmokeTrackerScreen.kt](file:///home/marcel/Schreibtisch/GreenTrackerWeb/composeApp/src/commonMain/kotlin/com/example/ui/screens/SmokeTrackerScreen.kt)
- **Settings**: Entfernen der Auswahl-Chips für das Erinnerungs-Intervall ("Aus", "1h", etc.).
- **SessionItemRow (iPhone Fix)**:
    - Umstrukturierung der Zeile: Die Uhrzeit erhält einen festen Platz, damit sie niemals in die nächste Zeile rutscht oder den Namen "verdrängt".
    - Der Name der Sorte wird konsequent gekürzt, falls der Platz nicht reicht.
    - Abstände werden für schmale Displays (iPhone 16) optimiert.

### 3. Benachrichtigungen (Stabilität)

#### [MODIFY] [NotificationManager.kt](file:///home/marcel/Schreibtisch/GreenTrackerWeb/composeApp/src/wasmJsMain/kotlin/com/example/util/NotificationManager.kt)
- Vereinfachung der `showWebNotification` Logik, um sicherzustellen, dass die "Test-Nachricht" und "Log-Bestätigung" zumindest bei aktiver App auf dem iPhone erscheinen.

## Verifizierungsplan

### Manuelle Verifizierung
1. **Layout**: Prüfen der Historie auf dem iPhone. Die Uhrzeit muss sauber rechts neben (oder fest positioniert beim) Namen stehen, ohne Zeilenumbruch.
2. **Einstellungen**: Das Menü "Benachrichtigungen" darf nur noch den Test-Button und die Schnell-Log-Menge enthalten.
3. **Loggen**: Beim Loggen prüfen, ob die Erfolgsmeldung erscheint.
