# Journal UI Redesign Mockup

Here is how I plan to redesign the Journal entry for a cleaner, more professional look.

### 📐 Layout Structure

```mermaid
graph TD
    subgraph Card ["Strain Journal Card"]
        direction LR
        ImageArea["[ 📸 Photo ]\n(72dp x 72dp)\n[ 👍 Badge ]"]

        subgraph Content ["Info Section"]
            direction TB
            Title["**Super Lemon Haze**\n(18sp Bold)"]
            Producer["*Green House Seeds* (13sp)"]

            subgraph Badges ["Stats Badges"]
                direction LR
                Cat["[ Sativa ]"]
                THC["[ 22% THC ]"]
                CBD["[ 1% CBD ]"]
            end

            Notes["*Smooth citrus taste...*"]
        end

        subgraph Actions ["Actions"]
            direction TB
            Edit["[ ✏️ Edit ]"]
            Delete["[ 🗑️ Delete ]"]
        end
    end
```

### ✨ Key Improvements:

1.  **Image & Rating**:
    *   The photo is now larger and more prominent.
    *   The **Thumb Up/Down** icon is moved out of the text area. It will be a small colored circle (Green for up, Red for down) overlaying the corner of the photo.
2.  **Typography & Contrast**:
    *   **Strain Name**: Much bigger and easier to read.
    *   **Badges**: Instead of tiny text, we use "Chips" with background colors (Purple for Indica, Orange for Sativa, Green for Hybrid). The THC and CBD numbers will be **bold and high-contrast**.
3.  **Alignment**:
    *   The **Edit** and **Delete** icons are moved to their own column on the far right. They are centered vertically, so they are always "in line" with each other, regardless of how much text you write.
4.  **Better Spacing**: Added more padding between the image and the text to make it feel less cramped.

---

### 📊 Stats Chart "Overlap" Fix:
I will also apply the fix where the bars only take up **65%** of the height, leaving a guaranteed **35% space** at the top for the labels (e.g., "2.6g"). This prevents them from ever touching the title again.

> [!TIP]
> **Does this layout look better to you?** If you like this "Badge" style, I can apply it to the code immediately.
