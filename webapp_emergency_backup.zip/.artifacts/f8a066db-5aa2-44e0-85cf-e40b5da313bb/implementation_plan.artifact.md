# Implementation Plan - Optimize Build Output & Silence Webpack Warnings

Address the Webpack performance warnings regarding asset size and investigate Gradle deprecations to ensure a future-proof and clean build process.

## User Review Required

> [!IMPORTANT]
> The "Asset Size" warning from Webpack is standard for Kotlin/Wasm apps using Compose, as the Skia rendering engine and Kotlin runtime naturally exceed the default 244 KiB limit. I will adjust the configuration to match the reality of Wasm applications.

## Proposed Changes

### [Webpack Configuration]

#### [NEW] [performance.js](file:///home/marcel/Schreibtisch/GreenTrackerWeb/composeApp/webpack.config.d/performance.js)
- Create a custom Webpack configuration to increase or disable performance hints for asset sizes.
- Set `maxAssetSize` and `maxEntrypointSize` to more realistic values for a Wasm application (e.g., 10 MiB).

```javascript
config.performance = {
    hints: false, // Or set higher limits
    maxEntrypointSize: 10 * 1024 * 1024,
    maxAssetSize: 10 * 1024 * 1024
};
```

### [Gradle Configuration]

#### [MODIFY] [build.gradle.kts](file:///home/marcel/Schreibtisch/GreenTrackerWeb/build.gradle.kts)
- Investigate and resolve the `archives` configuration deprecation. This is often related to how artifacts are declared in older KMP templates.

## Verification Plan

### Automated Tests
- Run `./gradlew :composeApp:wasmJsBrowserDistribution` and verify the Webpack performance warnings are gone.
- Run with `--warning-mode all` to verify if the Gradle `archives` deprecation is resolved.

### Manual Verification
- Check the size of the generated `.wasm` and `.js` files in `composeApp/build/dist/wasmJs/productionExecutable` to ensure they are within the new limits.
